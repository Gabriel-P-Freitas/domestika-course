</div>

<footer class="footer" id="page-footer" role="contentinfo">
	<?php get_sidebar( 'footer' ); ?>
</footer>

<?php wp_footer(); ?>
</body>
</html>
