<?php

function domestika_child_enqueue_scripts() {
  wp_enqueue_style( 'domestika-child', get_stylesheet_directory_uri() . '/style.css' );
}
add_action( 'wp_enqueue_scripts', 'domestika_child_enqueue_scripts' );
